/*
 * 블로그부스트 — 콘텐츠 스크립트 (네이버 스마트에디터 실시간 분석 + 플로팅 HUD)
 * - blog.naver.com / m.blog.naver.com / blog.editor.naver.com 의 모든 프레임에서 동작.
 * - 스마트에디터 ONE의 본문/제목을 감지해 Shadow DOM 패널을 띄운다.
 * - 글자수(공백 포함/제외), 키워드 출현 횟수·밀도, 제목 길이를 250ms 디바운스로 계산.
 * - 권한(Pro/체험/라이트)은 백그라운드에 물어보고, 키 원문은 이 스크립트로 내려오지 않는다.
 */
(function () {
  'use strict';

  if (window.__blogBoostContentV1) { return; }
  window.__blogBoostContentV1 = true;

  var HOST_ID = 'blogboost-hud-root';
  var DEBOUNCE_MS = 250;
  var WATCHDOG_MS = 1600;

  var TITLE_SELECTORS = [
    '.se-documentTitle .se-text-paragraph',
    '.se-documentTitle .se-text-paragraph-text',
    '.se-documentTitle',
    '.se-title-text',
    '.se-title .se-text-paragraph'
  ];

  var ALT_BODY_SELECTORS = [
    '.se2_inputarea',
    '.se-content',
    '#postViewArea .se_component_wrap'
  ];

  var state = {
    settings: null,
    entitlement: null,
    trial: null,
    analysis: null,
    mounted: false,
    addOpen: false,
    debounceTimer: null,
    drag: null,
    lastRenderKey: ''
  };

  var refs = {};

  // ------------------------------------------------------------------ utils
  function sendMessage(msg) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(msg, function (res) {
          if (chrome.runtime.lastError) { resolve(null); return; }
          resolve(res || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  function setText(el, value) {
    if (!el) { return; }
    var next = String(value);
    if (el.textContent !== next) { el.textContent = next; }
  }

  function codePoints(str) {
    return Array.from(String(str)).length;
  }

  function normalizeText(raw) {
    var t = String(raw === null || raw === undefined ? '' : raw);
    t = t.replace(/[\u200b\u200c\u200d\ufeff]/g, '');
    t = t.replace(/\u00a0/g, ' ');
    t = t.replace(/\r\n?/g, '\n');
    return t;
  }

  function isVisible(el) {
    if (!el || !el.isConnected) { return false; }
    var rect = el.getBoundingClientRect();
    if (rect.width < 40 || rect.height < 8) { return false; }
    var style = window.getComputedStyle(el);
    if (!style) { return true; }
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') { return false; }
    return true;
  }

  // --------------------------------------------------------- editor detection
  function detectEditor() {
    var editable = document.querySelector('[contenteditable="true"]');
    if (!editable) { return { found: false }; }

    var titleEl = null;
    for (var i = 0; i < TITLE_SELECTORS.length; i++) {
      var cand = document.querySelector(TITLE_SELECTORS[i]);
      if (cand && isVisible(cand)) { titleEl = cand; break; }
    }

    var paragraphs = document.querySelectorAll('.se-text-paragraph');
    var bodyEls = [];
    var j;
    for (j = 0; j < paragraphs.length; j++) {
      var el = paragraphs[j];
      if (titleEl && (el === titleEl || titleEl.contains(el) || el.contains(titleEl))) { continue; }
      if (el.closest && el.closest('.se-documentTitle')) { continue; }
      if (!isVisible(el)) { continue; }
      bodyEls.push(el);
    }

    if (!bodyEls.length) {
      for (j = 0; j < ALT_BODY_SELECTORS.length; j++) {
        var alt = document.querySelector(ALT_BODY_SELECTORS[j]);
        if (alt && isVisible(alt)) { bodyEls = [alt]; break; }
      }
    }

    if (!bodyEls.length) { return { found: false }; }
    return { found: true, titleEl: titleEl, bodyEls: bodyEls };
  }

  // -------------------------------------------------------------- analysis
  function analyzeKeyword(keyword, compactLower, totalNoSpace) {
    var needle = String(keyword || '').replace(/\s+/g, '');
    if (!needle) { return null; }
    var n = needle.toLowerCase();
    var count = 0;
    var from = 0;
    var guard = 0;
    while (guard < 20000) {
      var idx = compactLower.indexOf(n, from);
      if (idx === -1) { break; }
      count += 1;
      from = idx + n.length;
      guard += 1;
    }
    var share = totalNoSpace > 0 ? (codePoints(needle) * count) / totalNoSpace * 100 : 0;
    return {
      keyword: keyword,
      count: count,
      density: Math.round(share * 10) / 10
    };
  }

  function levelFor(density, count, settings) {
    if (!count) { return 'none'; }
    var min = settings.densityMin;
    var max = settings.densityMax;
    if (density < min) { return 'low'; }
    if (density > max) { return 'high'; }
    return 'good';
  }

  function analyze() {
    if (!state.settings) { return null; }
    var editor = detectEditor();
    if (!editor.found) { return null; }

    var parts = [];
    for (var i = 0; i < editor.bodyEls.length; i++) {
      var node = editor.bodyEls[i];
      parts.push(node.innerText || node.textContent || '');
    }
    var text = normalizeText(parts.join('\n'));
    var withSpace = codePoints(text);
    var compact = text.replace(/\s+/g, '');
    var noSpace = codePoints(compact);
    var trimmed = text.replace(/[ \t]+$/gm, '').trim();
    var words = trimmed ? trimmed.split(/\s+/).length : 0;

    var titleText = '';
    if (editor.titleEl) {
      titleText = normalizeText(editor.titleEl.innerText || editor.titleEl.textContent || '');
      titleText = titleText.replace(/\n+/g, ' ').trim();
    }

    var list = (state.settings.keywords || []).filter(function (k) { return !!k; }).slice(0, 3);
    var compactLower = compact.toLowerCase();
    var rows = [];
    for (var k = 0; k < list.length; k++) {
      var row = analyzeKeyword(list[k], compactLower, noSpace);
      if (!row) { continue; }
      row.level = levelFor(row.density, row.count, state.settings);
      rows.push(row);
    }

    return {
      withSpace: withSpace,
      noSpace: noSpace,
      words: words,
      titleText: titleText,
      titleLen: codePoints(titleText),
      keywords: rows,
      at: Date.now()
    };
  }

  function scheduleAnalyze() {
    if (state.debounceTimer) { clearTimeout(state.debounceTimer); }
    state.debounceTimer = setTimeout(function () {
      state.debounceTimer = null;
      runAnalysis();
    }, DEBOUNCE_MS);
  }

  function runAnalysis() {
    if (!state.settings || !state.settings.enabled) { return; }
    if (!document.getElementById(HOST_ID)) {
      if (!mountHud()) { return; }
    }
    var next = analyze();
    if (!next) {
      unmountHud();
      return;
    }
    state.analysis = next;
    render();
  }

  // ------------------------------------------------------------------- HUD
  function hudTemplate() {
    return [
      '<div class="bb-root" data-collapsed="false" data-tier="trial">',
      '  <div class="bb-head" data-role="head">',
      '    <span class="bb-mark"><i></i><i></i><i></i></span>',
      '    <span class="bb-name">블로그부스트</span>',
      '    <span class="bb-tag" data-role="tag">체험</span>',
      '    <span class="bb-summary" data-role="summary"></span>',
      '    <button class="bb-btn-icon" data-role="collapse" type="button" title="접기/펼치기">–</button>',
      '  </div>',
      '  <div class="bb-body">',
      '    <div class="bb-chars">',
      '      <div class="bb-stat">',
      '        <span class="bb-stat-label">공백 포함</span>',
      '        <span class="bb-stat-value" data-role="charsWith">0</span>',
      '      </div>',
      '      <div class="bb-stat">',
      '        <span class="bb-stat-label">공백 제외</span>',
      '        <span class="bb-stat-value" data-role="charsNo">0</span>',
      '      </div>',
      '    </div>',
      '    <div class="bb-kw-list" data-role="kwList"></div>',
      '    <div class="bb-title-row" data-role="titleRow">',
      '      <span class="bb-title-label">제목</span>',
      '      <span class="bb-title-num" data-role="titleNum">0/25</span>',
      '    </div>',
      '    <div class="bb-hint" data-role="hint"></div>',
      '    <div class="bb-locked bb-hidden" data-role="locked">',
      '      <div class="bb-locked-title">체험 종료 · 라이트 모드</div>',
      '      <div class="bb-locked-text">글자수·제목은 계속 무료입니다. 키워드 밀도와 신호등은 Pro에서 열립니다.</div>',
      '      <button class="bb-cta" data-role="buy" type="button">Pro 열기 (평생 1회 결제)</button>',
      '    </div>',
      '  </div>',
      '  <div class="bb-add bb-hidden" data-role="addForm">',
      '    <input type="text" maxlength="30" placeholder="키워드 입력 후 Enter" data-role="addInput">',
      '    <button type="button" data-role="addSave">추가</button>',
      '  </div>',
      '  <div class="bb-foot">',
      '    <span class="bb-foot-note" data-role="footNote">적정 구간 1.5~3.0%</span>',
      '    <button class="bb-mini" data-role="addKw" type="button">+ 키워드</button>',
      '  </div>',
      '</div>'
    ].join('');
  }

  function mountHud() {
    if (document.getElementById(HOST_ID)) {
      state.mounted = true;
      return true;
    }
    var editor = detectEditor();
    if (!editor.found) { return false; }

    var host = document.createElement('div');
    host.id = HOST_ID;
    var shadow = host.attachShadow({ mode: 'open' });

    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('content/content.css');
    shadow.appendChild(link);

    var wrapper = document.createElement('div');
    wrapper.innerHTML = hudTemplate();
    shadow.appendChild(wrapper);

    var root = shadow.querySelector('.bb-root');
    refs = {
      host: host,
      shadow: shadow,
      root: root,
      head: shadow.querySelector('[data-role="head"]'),
      tag: shadow.querySelector('[data-role="tag"]'),
      summary: shadow.querySelector('[data-role="summary"]'),
      collapse: shadow.querySelector('[data-role="collapse"]'),
      charsWith: shadow.querySelector('[data-role="charsWith"]'),
      charsNo: shadow.querySelector('[data-role="charsNo"]'),
      kwList: shadow.querySelector('[data-role="kwList"]'),
      titleRow: shadow.querySelector('[data-role="titleRow"]'),
      titleNum: shadow.querySelector('[data-role="titleNum"]'),
      hint: shadow.querySelector('[data-role="hint"]'),
      locked: shadow.querySelector('[data-role="locked"]'),
      buy: shadow.querySelector('[data-role="buy"]'),
      addForm: shadow.querySelector('[data-role="addForm"]'),
      addInput: shadow.querySelector('[data-role="addInput"]'),
      addSave: shadow.querySelector('[data-role="addSave"]'),
      addKw: shadow.querySelector('[data-role="addKw"]'),
      footNote: shadow.querySelector('[data-role="footNote"]')
    };

    if (link && link.addEventListener) {
      link.addEventListener('load', function () { root.classList.add('bb-ready'); });
      link.addEventListener('error', function () { root.classList.add('bb-ready'); });
      setTimeout(function () { root.classList.add('bb-ready'); }, 600);
    } else {
      root.classList.add('bb-ready');
    }

    applyPosition();
    bindHudEvents();

    var container = document.body || document.documentElement;
    container.appendChild(host);
    state.mounted = true;
    recordSessionOnce();
    return true;
  }

  function unmountHud() {
    var host = document.getElementById(HOST_ID);
    if (host && host.parentNode) { host.parentNode.removeChild(host); }
    state.mounted = false;
    refs = {};
  }

  function applyPosition() {
    if (!refs.host) { return; }
    var pos = state.settings && state.settings.position ? state.settings.position : null;
    if (!pos) {
      refs.host.style.left = 'auto';
      refs.host.style.top = 'auto';
      refs.host.style.right = '20px';
      refs.host.style.bottom = '20px';
      return;
    }
    var width = 260;
    var height = 220;
    var x = Math.max(4, Math.min(pos.x, window.innerWidth - width - 4));
    var y = Math.max(4, Math.min(pos.y, window.innerHeight - height - 4));
    refs.host.style.left = x + 'px';
    refs.host.style.top = y + 'px';
    refs.host.style.right = 'auto';
    refs.host.style.bottom = 'auto';
  }

  function bindHudEvents() {
    if (!refs.root) { return; }

    refs.collapse.addEventListener('click', function (ev) {
      ev.stopPropagation();
      var next = !(state.settings && state.settings.collapsed);
      saveSetting({ collapsed: next });
    });

    refs.buy.addEventListener('click', function () {
      sendMessage({ type: 'bb:openStore' });
    });

    refs.addKw.addEventListener('click', function () {
      state.addOpen = !state.addOpen;
      refs.addForm.classList.toggle('bb-hidden', !state.addOpen);
      if (state.addOpen) {
        refs.addInput.value = '';
        refs.addInput.focus();
        var settings = state.settings || {};
        var full = (settings.keywords || []).filter(function (k) { return !!k; }).length >= 3;
        setText(refs.footNote, full ? '키워드는 최대 3개' : '키워드 추가');
      } else {
        setText(refs.footNote, footNoteText());
      }
    });

    refs.addSave.addEventListener('click', submitKeyword);
    refs.addInput.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        submitKeyword();
      } else if (ev.key === 'Escape') {
        state.addOpen = false;
        refs.addForm.classList.add('bb-hidden');
        setText(refs.footNote, footNoteText());
      }
    });

    refs.kwList.addEventListener('click', function (ev) {
      var btn = ev.target;
      if (!btn || !btn.getAttribute) { return; }
      var index = btn.getAttribute('data-kw-index');
      if (index === null) { return; }
      var idx = parseInt(index, 10);
      if (isNaN(idx) || idx < 0 || idx > 2) { return; }
      var next = (state.settings.keywords || ['', '', '']).slice(0, 3);
      next[idx] = '';
      saveSetting({ keywords: next });
    });

    bindDrag();
    window.addEventListener('resize', function () {
      if (refs.host && state.settings && state.settings.position) { applyPosition(); }
    });
  }

  function bindDrag() {
    var head = refs.head;
    if (!head) { return; }

    head.addEventListener('pointerdown', function (ev) {
      if (ev.target && ev.target.getAttribute && ev.target.getAttribute('data-role') === 'collapse') { return; }
      var rect = refs.host.getBoundingClientRect();
      state.drag = {
        startX: ev.clientX,
        startY: ev.clientY,
        left: rect.left,
        top: rect.top,
        moved: false
      };
      if (head.setPointerCapture && ev.pointerId !== undefined) {
        try { head.setPointerCapture(ev.pointerId); } catch (e) { /* noop */ }
      }
      ev.preventDefault();
    });

    head.addEventListener('pointermove', function (ev) {
      if (!state.drag) { return; }
      var dx = ev.clientX - state.drag.startX;
      var dy = ev.clientY - state.drag.startY;
      if (!state.drag.moved && Math.abs(dx) < 3 && Math.abs(dy) < 3) { return; }
      state.drag.moved = true;
      var width = refs.host.offsetWidth || 260;
      var height = refs.host.offsetHeight || 200;
      var x = Math.max(4, Math.min(state.drag.left + dx, window.innerWidth - width - 4));
      var y = Math.max(4, Math.min(state.drag.top + dy, window.innerHeight - height - 4));
      refs.host.style.left = x + 'px';
      refs.host.style.top = y + 'px';
      refs.host.style.right = 'auto';
      refs.host.style.bottom = 'auto';
    });

    function endDrag() {
      if (!state.drag) { return; }
      var moved = state.drag.moved;
      state.drag = null;
      if (!moved || !refs.host) { return; }
      var rect = refs.host.getBoundingClientRect();
      saveSetting({ position: { x: Math.round(rect.left), y: Math.round(rect.top) } });
    }

    head.addEventListener('pointerup', endDrag);
    head.addEventListener('pointercancel', endDrag);
    window.addEventListener('pointerup', endDrag);
  }

  function submitKeyword() {
    if (!refs.addInput) { return; }
    var value = String(refs.addInput.value || '').replace(/\s+/g, ' ').trim().slice(0, 30);
    if (!value) { return; }
    var current = (state.settings.keywords || ['', '', '']).slice(0, 3);
    var slot = -1;
    for (var i = 0; i < 3; i++) {
      if (!current[i]) { slot = i; break; }
    }
    if (slot === -1) {
      setText(refs.footNote, '키워드는 최대 3개');
      return;
    }
    if (current.some(function (k) { return k.toLowerCase() === value.toLowerCase(); })) {
      setText(refs.footNote, '이미 등록된 키워드');
      return;
    }
    current[slot] = value;
    state.addOpen = false;
    refs.addForm.classList.add('bb-hidden');
    refs.addInput.value = '';
    saveSetting({ keywords: current });
  }

  function footNoteText() {
    if (!state.settings) { return '적정 구간 1.5~3.0%'; }
    return '적정 구간 ' + state.settings.densityMin.toFixed(1) + '~' + state.settings.densityMax.toFixed(1) + '%';
  }

  function saveSetting(patch) {
    var merged = Object.assign({}, state.settings || {}, patch);
    state.settings = merged;
    render();
    sendMessage({ type: 'bb:patchSettings', patch: patch }).then(function (res) {
      if (res && res.ok) {
        state.settings = res.settings;
        state.entitlement = res.entitlement;
        state.trial = res.trial;
        scheduleAnalyze();
      }
    });
  }

  // ------------------------------------------------------------------ render
  function render() {
    if (!state.mounted || !refs.root) { return; }
    var settings = state.settings;
    var ent = state.entitlement;
    var trial = state.trial;
    var a = state.analysis;
    if (!settings) { return; }

    var tier = ent ? ent.tier : 'trial';
    refs.root.setAttribute('data-tier', tier);
    refs.root.setAttribute('data-collapsed', settings.collapsed ? 'true' : 'false');
    setText(refs.collapse, settings.collapsed ? '+' : '–');

    var tagText = '체험';
    if (tier === 'pro') { tagText = 'PRO'; }
    else if (tier === 'trial') { tagText = '체험 D-' + (trial ? trial.daysLeft : 3); }
    else { tagText = '라이트'; }
    setText(refs.tag, tagText);
    refs.tag.setAttribute('data-tier', tier);

    setText(refs.charsWith, a ? a.withSpace.toLocaleString('ko-KR') : '0');
    setText(refs.charsNo, a ? a.noSpace.toLocaleString('ko-KR') : '0');

    var unlocked = ent ? ent.densityUnlocked : true;
    refs.locked.classList.toggle('bb-hidden', unlocked);
    refs.kwList.classList.toggle('bb-hidden', !unlocked);

    if (unlocked) {
      renderKeywords(a, settings);
    } else {
      refs.kwList.innerHTML = '';
    }

    var limit = settings.titleLimit;
    var titleLen = a ? a.titleLen : 0;
    setText(refs.titleNum, titleLen + '/' + limit);
    var titleLevel = titleLen > limit ? 'long' : (titleLen > 0 && titleLen < 10 ? 'short' : 'ok');
    refs.titleNum.setAttribute('data-level', titleLevel);

    var summary = '';
    if (settings.collapsed && a) {
      summary = a.withSpace.toLocaleString('ko-KR') + '자';
      if (unlocked && a.keywords.length) { summary += ' · ' + a.keywords[0].density.toFixed(1) + '%'; }
    }
    setText(refs.summary, summary);

    var hint = buildHint(a, settings, unlocked);
    setText(refs.hint, hint.text);
    refs.hint.setAttribute('data-tone', hint.tone);
    refs.hint.classList.toggle('bb-hidden', !settings.showHints || !hint.text);

    if (!state.addOpen) { setText(refs.footNote, footNoteText()); }
  }

  function renderKeywords(a, settings) {
    if (!a || !a.keywords.length) {
      var empty = document.createElement('div');
      empty.className = 'bb-kw-empty';
      empty.textContent = '키워드를 등록하면 출현 횟수와 밀도를 계산합니다.';
      refs.kwList.innerHTML = '';
      refs.kwList.appendChild(empty);
      return;
    }
    var all = (settings.keywords || ['', '', '']);
    var html = [];
    for (var i = 0; i < a.keywords.length; i++) {
      var row = a.keywords[i];
      var displayCount = row.count;
      var pct = row.count ? row.density.toFixed(1) + '%' : '0%';
      var title = levelTitle(row.level, settings);
      html.push(
        '<div class="bb-kw" data-level="' + row.level + '" title="' + escapeAttr(title) + '">' +
          '<span class="bb-dot"></span>' +
          '<span class="bb-kw-name">' + escapeHtml(row.keyword) + '</span>' +
          '<span class="bb-kw-num">' + displayCount + '회</span>' +
          '<span class="bb-kw-pct">' + pct + '</span>' +
          '<button class="bb-kw-x" type="button" data-kw-index="' + all.indexOf(row.keyword) + '" title="삭제">×</button>' +
        '</div>'
      );
    }
    refs.kwList.innerHTML = html.join('');
  }

  function levelTitle(level, settings) {
    var min = settings.densityMin.toFixed(1);
    var max = settings.densityMax.toFixed(1);
    if (level === 'good') { return '적정 구간(' + min + '~' + max + '%)입니다.'; }
    if (level === 'low') { return '부족(' + min + '% 미만) — 본문에 한두 번 더 자연스럽게 넣어보세요.'; }
    if (level === 'high') { return '과다(' + max + '% 초과) — 같은 표현이 반복되면 저품질 위험이 커집니다.'; }
    return '본문에 아직 이 키워드가 없습니다.';
  }

  function buildHint(a, settings, unlocked) {
    if (!a) { return { text: '', tone: 'none' }; }
    var limit = settings.titleLimit;
    if (a.titleLen > limit) {
      return {
        text: '제목이 ' + a.titleLen + '자입니다. 모바일에서 잘리지 않게 ' + limit + '자 안팎을 권장합니다.',
        tone: 'high'
      };
    }
    if (!unlocked) {
      return { text: '', tone: 'none' };
    }
    if (!a.keywords.length) {
      return { text: '핵심 키워드를 등록하면 밀도 신호등이 켜집니다.', tone: 'none' };
    }
    var mine = a.keywords[0];
    if (mine.level === 'high') {
      return { text: '‘' + mine.keyword + '’ 밀도가 높습니다. 문장을 늘려 ' + settings.densityMax.toFixed(1) + '% 아래로 낮추세요.', tone: 'high' };
    }
    if (mine.level === 'low' || mine.level === 'none') {
      return { text: '‘' + mine.keyword + '’가 ' + (mine.level === 'none' ? '본문에 없습니다' : '조금 부족합니다') + '. 한두 번 더 넣어보세요.', tone: 'low' };
    }
    return { text: '‘' + mine.keyword + '’ 밀도 적정. 이대로 발행해도 좋습니다.', tone: 'good' };
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch];
    });
  }

  function escapeAttr(str) {
    return escapeHtml(str).replace(/\n/g, ' ');
  }

  // ------------------------------------------------------------- session/trial
  function recordSessionOnce() {
    try {
      if (sessionStorage.getItem('bb_session') === '1') { return; }
      sessionStorage.setItem('bb_session', '1');
    } catch (e) {
      // 시크릿 모드 등 sessionStorage 차단 시에도 서버 측 중복 방지(10분 창)가 있다.
    }
    sendMessage({ type: 'bb:recordSession' }).then(function (res) {
      if (res && res.ok) {
        state.settings = res.settings;
        state.entitlement = res.entitlement;
        state.trial = res.trial;
        render();
      }
    });
  }

  // --------------------------------------------------------------- observers
  function onStorageChanged(changes, area) {
    if (area !== 'local') { return; }
    var relevant = false;
    Object.keys(changes).forEach(function (key) {
      if (key === 'bb_settings' || key === 'bb_license' || key === 'bb_trial') { relevant = true; }
    });
    if (!relevant) { return; }
    refreshState();
  }

  var refreshTimer = null;
  function refreshState() {
    if (refreshTimer) { clearTimeout(refreshTimer); }
    refreshTimer = setTimeout(function () {
      refreshTimer = null;
      sendMessage({ type: 'bb:getState' }).then(function (res) {
        if (!res || !res.ok) { return; }
        state.settings = res.settings;
        state.entitlement = res.entitlement;
        state.trial = res.trial;
        if (!res.settings.enabled) {
          unmountHud();
          return;
        }
        if (!document.getElementById(HOST_ID)) { mountHud(); }
        applyPosition();
        scheduleAnalyze();
        render();
      });
    }, 150);
  }

  function watch() {
    setInterval(function () {
      if (!state.settings || !state.settings.enabled) { return; }
      var ed = detectEditor();
      if (ed.found && !document.getElementById(HOST_ID)) {
        mountHud();
        scheduleAnalyze();
      } else if (!ed.found && document.getElementById(HOST_ID)) {
        unmountHud();
      }
    }, WATCHDOG_MS);
  }

  function init() {
    sendMessage({ type: 'bb:getState' }).then(function (res) {
      if (!res || !res.ok) {
        setTimeout(init, 1200);
        return;
      }
      state.settings = res.settings;
      state.entitlement = res.entitlement;
      state.trial = res.trial;
      if (!state.settings.enabled) { return; }
      if (mountHud()) { scheduleAnalyze(); }
      watch();
    });

    try {
      chrome.storage.onChanged.addListener(onStorageChanged);
    } catch (e) { /* noop */ }

    document.addEventListener('input', scheduleAnalyze, true);
    document.addEventListener('keyup', scheduleAnalyze, true);
    document.addEventListener('paste', function () { setTimeout(scheduleAnalyze, 80); }, true);

    var observer = new MutationObserver(function () {
      if (!state.settings || !state.settings.enabled) { return; }
      scheduleAnalyze();
    });
    var tryObserve = function () {
      if (!document.body) { return false; }
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      return true;
    };
    if (!tryObserve()) {
      document.addEventListener('DOMContentLoaded', tryObserve, { once: true });
    }
  }

  init();
})();
