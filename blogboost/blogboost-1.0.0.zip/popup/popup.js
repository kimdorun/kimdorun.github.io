/*
 * 블로그부스트 — 팝업 로직
 * 모든 상태 변경은 백그라운드 서비스 워커(lib/license.js)에 위임한다.
 */
(function () {
  'use strict';

  var el = {};
  var state = null;
  var busy = false;

  function $(id) { return document.getElementById(id); }

  function send(msg) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(msg, function (res) {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(res || { ok: false });
      });
    });
  }

  function formatDate(ts) {
    if (!ts) { return '-'; }
    try {
      return new Date(ts).toLocaleDateString('ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit' });
    } catch (e) {
      return '-';
    }
  }

  function planLabel(plan) {
    if (plan === 'lifetime') { return '평생 라이선스'; }
    if (plan === 'subscription') { return '구독'; }
    return plan || '-';
  }

  function setMessage(text, tone) {
    el.licenseMsg.textContent = text || '';
    if (tone) { el.licenseMsg.setAttribute('data-tone', tone); }
    else { el.licenseMsg.removeAttribute('data-tone'); }
  }

  function setBusy(isBusy, label) {
    busy = isBusy;
    el.activateBtn.disabled = isBusy;
    el.refreshBtn.disabled = isBusy;
    el.deactivateBtn.disabled = isBusy;
    el.activateBtn.textContent = isBusy ? (label || '확인 중…') : '활성화';
  }

  // ------------------------------------------------------------------ render
  function render(data) {
    if (!data || !data.ok) { return; }
    state = data;
    var ent = data.entitlement;
    var trial = data.trial;
    var license = data.license;
    var settings = data.settings;

    // 1) 배지
    var pillText = '라이트';
    if (ent.pro) { pillText = 'PRO'; }
    else if (trial.active) { pillText = '체험 D-' + trial.daysLeft; }
    el.tierPill.textContent = pillText;
    el.tierPill.setAttribute('data-tier', ent.tier);

    // 2) 상태 카드
    if (ent.pro) {
      el.statusTitle.textContent = 'Pro 활성';
      el.statusSub.textContent = '키워드 밀도·신호등·제목 경고를 모두 사용 중입니다.';
      el.trialMeters.classList.add('hidden');
      el.licenseInfo.classList.remove('hidden');
      el.licKey.textContent = license.maskedKey || '-';
      el.licPlan.textContent = planLabel(license.plan);
      el.licChecked.textContent = formatDate(license.validatedAt);
      el.statusNote.textContent = license.offline
        ? '오프라인 확인 상태입니다. ' + license.offlineDaysLeft + '일 안에 한 번 인터넷에 연결해 주세요.'
        : '발행 전 마지막 점검까지, 블로그부스트가 옆에서 봅니다.';
      el.deactivateBtn.classList.remove('hidden');
      el.offlineNote.classList.add('hidden');
    } else {
      el.statusTitle.textContent = trial.active ? '무료 체험 중' : '체험 종료 · 라이트 모드';
      el.statusSub.textContent = trial.active
        ? '글자수·제목·키워드 밀도를 모두 써 보세요. 체험 후에도 글자수는 계속 무료입니다.'
        : '글자수와 제목은 계속 무료입니다. 키워드 밀도와 신호등은 Pro에서 열립니다.';
      el.trialMeters.classList.toggle('hidden', !trial.started);
      el.licenseInfo.classList.toggle('hidden', !license.maskedKey);
      if (license.maskedKey) {
        el.licKey.textContent = license.maskedKey;
        el.licPlan.textContent = planLabel(license.plan);
        el.licChecked.textContent = formatDate(license.validatedAt);
      }
      el.statusNote.textContent = trial.active
        ? '남은 체험: ' + trial.daysLeft + '일 · ' + trial.sessionsLeft + '회 (사용할 때마다 차감)'
        : 'Pro는 평생 1회 결제입니다. 한 번 사면 계속 씁니다.';
      el.deactivateBtn.classList.toggle('hidden', !license.maskedKey);
      if (license.status === 'revalidate_required' || license.status === 'tampered') {
        el.offlineNote.classList.remove('hidden');
        el.offlineNote.textContent = license.status === 'tampered'
          ? '라이선스 캐시가 손상되었습니다. 키를 다시 등록해 주세요.'
          : '오래 오프라인이었습니다. 인터넷에 연결한 뒤 [재확인]을 눌러 주세요.';
      } else {
        el.offlineNote.classList.add('hidden');
      }
    }

    // 3) 미터
    var dayPct = Math.max(0, Math.min(100, (trial.daysLeft / trial.totalDays) * 100));
    var sesPct = Math.max(0, Math.min(100, (trial.sessionsLeft / trial.totalSessions) * 100));
    el.daysLeft.textContent = trial.daysLeft + '일';
    el.sessionsLeft.textContent = trial.sessionsLeft + '회';
    el.daysBar.style.width = dayPct + '%';
    el.sessionsBar.style.width = sesPct + '%';
    el.daysBar.setAttribute('data-tone', dayPct <= 34 ? 'danger' : (dayPct <= 67 ? 'warn' : 'ok'));
    el.sessionsBar.setAttribute('data-tone', sesPct <= 20 ? 'danger' : (sesPct <= 50 ? 'warn' : 'ok'));

    // 4) 설정
    var kws = settings.keywords || ['', '', ''];
    for (var i = 0; i < 3; i++) {
      var input = $('kw' + i);
      if (input && document.activeElement !== input) { input.value = kws[i] || ''; }
    }
    el.toggleEnabled.checked = settings.enabled !== false;
    el.toggleHints.checked = settings.showHints !== false;
    el.titleLimit.value = String(settings.titleLimit);

    // 5) 라이선스 폼
    el.providerLabel.textContent = data.meta && data.meta.provider === 'paddle' ? 'Paddle' : 'Lemon Squeezy';
    el.versionLabel.textContent = 'v' + (chrome.runtime.getManifest().version || '1.0.0');
  }

  // ------------------------------------------------------------------ actions
  function load() {
    send({ type: 'bb:getState' }).then(function (res) {
      if (!res || !res.ok) { return; }
      render(res);
    }).catch(function () { /* 서비스 워커 기동 중 */ });
  }

  function saveKeywords() {
    var keywords = [el.kw0.value, el.kw1.value, el.kw2.value];
    var cleaned = keywords.map(function (k) { return String(k || '').replace(/\s+/g, ' ').trim().slice(0, 30); });
    send({ type: 'bb:patchSettings', patch: { keywords: cleaned } }).then(function (res) {
      if (res && res.ok) {
        render(res);
        el.saveState.textContent = '저장됨';
        setTimeout(function () { el.saveState.textContent = ''; }, 1600);
      } else {
        el.saveState.textContent = '저장 실패';
      }
    }).catch(function () {
      el.saveState.textContent = '저장 실패';
    });
  }

  function patch(patchObj) {
    send({ type: 'bb:patchSettings', patch: patchObj }).then(function (res) {
      if (res && res.ok) { render(res); }
    }).catch(function () { /* noop */ });
  }

  function activate() {
    if (busy) { return; }
    var key = el.licenseInput.value.trim();
    if (!key) {
      setMessage('라이선스 키를 입력해 주세요.', 'error');
      el.licenseInput.focus();
      return;
    }
    setBusy(true, '확인 중…');
    setMessage('', '');
    send({ type: 'bb:activate', key: key }).then(function (res) {
      setBusy(false);
      if (res && res.ok) {
        setMessage(res.message || 'Pro가 활성화되었습니다.', 'ok');
        el.licenseInput.value = '';
        if (res.state) { render(res.state); }
      } else {
        setMessage((res && res.message) || '라이선스를 확인하지 못했습니다.', 'error');
        if (res && res.state) { render(res.state); }
      }
    }).catch(function (err) {
      setBusy(false);
      setMessage('오류: ' + (err && err.message ? err.message : '알 수 없는 오류'), 'error');
    });
  }

  function deactivate() {
    if (busy) { return; }
    setBusy(true, '해제 중…');
    send({ type: 'bb:deactivate' }).then(function (res) {
      setBusy(false);
      if (res && res.state) { render(res.state); }
      setMessage(res && res.ok ? '이 기기에서 라이선스를 해제했습니다.' : '해제하지 못했습니다.', res && res.ok ? 'ok' : 'error');
    }).catch(function () {
      setBusy(false);
      setMessage('해제하지 못했습니다.', 'error');
    });
  }

  function refresh() {
    if (busy) { return; }
    setBusy(true, '재확인 중…');
    setMessage('', '');
    send({ type: 'bb:refresh' }).then(function (res) {
      setBusy(false);
      if (res && res.state) { render(res.state); }
      if (res && res.ok) { setMessage('최신 상태로 확인했습니다.', 'ok'); }
      else { setMessage((res && res.message) || '확인하지 못했습니다.', 'error'); }
    }).catch(function () {
      setBusy(false);
      setMessage('확인하지 못했습니다.', 'error');
    });
  }

  // --------------------------------------------------------------------- boot
  document.addEventListener('DOMContentLoaded', function () {
    el = {
      tierPill: $('tierPill'),
      statusTitle: $('statusTitle'),
      statusSub: $('statusSub'),
      trialMeters: $('trialMeters'),
      daysLeft: $('daysLeft'),
      sessionsLeft: $('sessionsLeft'),
      daysBar: $('daysBar'),
      sessionsBar: $('sessionsBar'),
      licenseInfo: $('licenseInfo'),
      licKey: $('licKey'),
      licPlan: $('licPlan'),
      licChecked: $('licChecked'),
      statusNote: $('statusNote'),
      offlineNote: $('offlineNote'),
      refreshBtn: $('refreshBtn'),
      kw0: $('kw0'),
      kw1: $('kw1'),
      kw2: $('kw2'),
      saveKwBtn: $('saveKwBtn'),
      saveState: $('saveState'),
      toggleEnabled: $('toggleEnabled'),
      toggleHints: $('toggleHints'),
      titleLimit: $('titleLimit'),
      resetPosBtn: $('resetPosBtn'),
      licenseForm: $('licenseForm'),
      licenseInput: $('licenseInput'),
      activateBtn: $('activateBtn'),
      licenseMsg: $('licenseMsg'),
      deactivateBtn: $('deactivateBtn'),
      buyBtn: $('buyBtn'),
      supportBtn: $('supportBtn'),
      providerLabel: $('providerLabel'),
      versionLabel: $('versionLabel')
    };

    load();

    el.saveKwBtn.addEventListener('click', saveKeywords);
    [el.kw0, el.kw1, el.kw2].forEach(function (input) {
      input.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') { ev.preventDefault(); saveKeywords(); }
      });
    });

    el.toggleEnabled.addEventListener('change', function () { patch({ enabled: el.toggleEnabled.checked }); });
    el.toggleHints.addEventListener('change', function () { patch({ showHints: el.toggleHints.checked }); });
    el.titleLimit.addEventListener('change', function () { patch({ titleLimit: parseInt(el.titleLimit.value, 10) }); });
    el.resetPosBtn.addEventListener('click', function () {
      patch({ position: null });
      el.resetPosBtn.textContent = '위치를 초기화했습니다';
      setTimeout(function () { el.resetPosBtn.textContent = '위젯 위치 초기화'; }, 1600);
    });

    el.activateBtn.addEventListener('click', activate);
    el.licenseInput.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') { ev.preventDefault(); activate(); }
    });
    el.deactivateBtn.addEventListener('click', deactivate);
    el.refreshBtn.addEventListener('click', refresh);
    el.buyBtn.addEventListener('click', function () { send({ type: 'bb:openStore' }); });
    el.supportBtn.addEventListener('click', function () { send({ type: 'bb:openSupport' }); });

    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local') { return; }
      var relevant = Object.keys(changes).some(function (k) {
        return k === 'bb_settings' || k === 'bb_license' || k === 'bb_trial';
      });
      if (relevant && !busy) { load(); }
    });
  });
})();
