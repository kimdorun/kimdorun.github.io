/*
 * 블로그부스트 — 백그라운드 서비스 워커 (Manifest V3)
 * - 라이선스 상태의 단일 창구. 콘텐츠 스크립트·팝업은 모두 여기로 메시지를 보낸다.
 * - 하루 1회(12시간 주기 알람) 라이선스 재검증, 배지로 상태 표시.
 */
importScripts('/lib/license.js');

var L = self.BlogBoostLicense;
var REVALIDATE_ALARM = 'bb:revalidate';
var REVALIDATE_PERIOD_MIN = 12 * 60;

function logError(where, err) {
  try { console.warn('[BlogBoost] ' + where, err); } catch (e) { /* noop */ }
}

async function updateBadge() {
  try {
    var state = await L.getState();
    var text = '';
    var color = '#6366f1';
    if (state.entitlement.pro) {
      text = 'PRO';
      color = '#16a34a';
    } else if (state.trial.active) {
      var days = state.trial.daysLeft;
      text = days > 0 ? String(days) + 'd' : '';
      color = '#f59e0b';
    } else {
      text = '';
      color = '#94a3b8';
    }
    await chrome.action.setBadgeBackgroundColor({ color: color });
    await chrome.action.setBadgeText({ text: text });
    await chrome.action.setTitle({
      title: state.entitlement.pro
        ? '블로그부스트 — Pro 활성'
        : (state.trial.active
          ? '블로그부스트 — 무료 체험 D-' + state.trial.daysLeft + ' (사용 ' + state.trial.sessionsUsed + '/' + state.trial.totalSessions + ')'
          : '블로그부스트 — 라이트 모드 (Pro로 업그레이드)')
    });
  } catch (e) {
    logError('updateBadge', e);
  }
}

function ensureAlarms() {
  chrome.alarms.get(REVALIDATE_ALARM, function (alarm) {
    if (!alarm) {
      chrome.alarms.create(REVALIDATE_ALARM, { periodInMinutes: REVALIDATE_PERIOD_MIN, delayInMinutes: 1 });
    }
  });
}

chrome.runtime.onInstalled.addListener(function (details) {
  L.bootstrap().then(function () {
    ensureAlarms();
    return updateBadge();
  }).catch(function (e) { logError('onInstalled', e); });
  if (details && details.reason === 'update') {
    L.bootstrap().catch(function (e) { logError('onInstalled:update', e); });
  }
});

chrome.runtime.onStartup.addListener(function () {
  L.bootstrap().then(function () {
    ensureAlarms();
    return updateBadge();
  }).catch(function (e) { logError('onStartup', e); });
});

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm.name !== REVALIDATE_ALARM) { return; }
  L.refreshIfNeeded({}).then(function () {
    return updateBadge();
  }).catch(function (e) { logError('alarm', e); });
});

async function handleMessage(msg, sender) {
  switch (msg.type) {
    case 'bb:getState':
      return await L.getState();

    case 'bb:recordSession':
      await L.recordSession();
      await updateBadge();
      return await L.getState();

    case 'bb:patchSettings':
      await L.patchSettings(msg.patch || {});
      return await L.getState();

    case 'bb:activate':
      var result = await L.activate(msg.key);
      await updateBadge();
      if (!result.ok && !result.entitlement) {
        result.state = await L.getState();
      } else if (result.ok) {
        result.state = await L.getState();
      }
      return result;

    case 'bb:deactivate':
      var off = await L.deactivate();
      await updateBadge();
      off.state = await L.getState();
      return off;

    case 'bb:refresh':
      var refreshed = await L.refreshIfNeeded({ force: true });
      await updateBadge();
      refreshed.state = await L.getState();
      return refreshed;

    case 'bb:openStore':
      await chrome.tabs.create({ url: msg.url || L.STORE_URL });
      return { ok: true };

    case 'bb:openSupport':
      await chrome.tabs.create({ url: 'mailto:' + L.SUPPORT_EMAIL + '?subject=' + encodeURIComponent('블로그부스트 문의') });
      return { ok: true };

    case 'bb:ping':
      return { ok: true, version: chrome.runtime.getManifest().version };

    case 'bb:diagnostics':
      var state = await L.getState();
      return {
        ok: true,
        manifest: chrome.runtime.getManifest().version,
        state: state,
        provider: L.PROVIDER.provider,
        cache: L.CACHE,
        sender: sender && sender.tab ? { url: sender.tab.url, id: sender.tab.id } : null
      };

    default:
      return { ok: false, error: 'unknown_message', type: msg.type };
  }
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg.type !== 'string' || msg.type.indexOf('bb:') !== 0) { return; }
  handleMessage(msg, sender).then(function (result) {
    sendResponse(result || { ok: false });
  }).catch(function (e) {
    logError('message:' + msg.type, e);
    sendResponse({ ok: false, error: String(e && e.message ? e.message : e) });
  });
  return true; // 비동기 응답 유지
});
